package main

import (
	"{appName}/routers"
	"github.com/yang-f/beauty/router"
	"github.com/yang-f/beauty/settings"
	"github.com/yang-f/beauty/utils/log"
	"net/http"
	"runtime"
)

func main() {
	runtime.GOMAXPROCS(2)
	log.Printf("start server on port %s", settings.Listen)
	routers.Set()
	settings.Domain = "yourdomain.com"
	settings.LogFile = "/var/log/you/path.log"
	settings.DefaultOrigin = "http://origindomain.com"
	settings.HmacSampleSecret = []byte("whatever")
	router := router.NewRouter()
	log.Fatal(http.ListenAndServe(settings.Listen, router))
}
