package main

import (
	"{appName}/controllers"
	"github.com/yang-f/beauty/router"
	"github.com/yang-f/beauty/decorates"
	"github.com/yang-f/beauty/settings"
	"github.com/yang-f/beauty/utils/log"
	"net/http"
	"runtime"
)

func main() {
	runtime.GOMAXPROCS(2)
	log.Printf("start server on port %s", settings.Listen)
	settings.Domain = "yourdomain.com"
	settings.LogFile = "/var/log/you/path.log"
	settings.DefaultOrigin = "http://origindomain.com"
	settings.HmacSampleSecret = []byte("whatever")
	r := router.New()
	r.GET("/", decorates.Handler(controllers.Config).ContentJSON())
	r.GET("/demo1", decorates.Handler(controllers.Config).ContentJSON().Auth())
	r.GET("/demo2", decorates.Handler(controllers.Config).ContentJSON().Verify())
	r.GET("/demo3", decorates.Handler(controllers.Config).ContentJSON().Auth().Verify())
	log.Fatal(http.ListenAndServe(settings.Listen, r))
}
