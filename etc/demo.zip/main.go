package main

import (
	"{appName}/controllers"
	"github.com/yang-f/beauty/router"
	"github.com/yang-f/beauty/settings"
	"log"
	"net/http"
	"runtime"
)

func main() {
	runtime.GOMAXPROCS(2)
	log.Printf("start server on port %s", settings.Listen)
	settings.Domain = "yourdomain.com"
	settings.DefaultOrigin = "http://origindomain.com"
	settings.HmacSampleSecret = []byte("whatever")
	r := router.New()
	r.GET("/", controllers.Config().ContentJSON())
	r.GET("/demo1", controllers.Config().ContentJSON().Verify())
	log.Fatal(http.ListenAndServe(settings.Listen, r))
}
