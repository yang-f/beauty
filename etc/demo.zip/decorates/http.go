package decorates

import "github.com/yang-f/beauty/decorates"

type Handler = decorates.Handler
