package routers

import (
	. "{appName}/controllers"
	"github.com/yang-f/beauty/consts/contenttype"
	. "github.com/yang-f/beauty/decorates"
	. "github.com/yang-f/beauty/router"
)

func Set() {

	BRoutes = Routes{
		Route{
			"nothing",
			"GET",
			"/",
			Config,
			contenttype.JSON,
		},
		Route{
			"authDemo",
			"GET",
			"/demo1",
			Handler(Config).
				Auth(),
			contenttype.JSON,
		},
		Route{
			"verifyDemo",
			"GET",
			"/demo2",
			Handler(Config).
				Verify(),
			contenttype.JSON,
		},
		Route{
			"verifyAndAuthDemo",
			"GET",
			"/demo3",
			Handler(Config).
				Auth().
				Verify(),
			contenttype.JSON,
		},
	}
}
